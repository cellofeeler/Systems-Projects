// Copyringht  2024 Neil Kirby not for disclosure wiothout permission

// system libraries rarely have bugs, do them first
#include <stdbool.h>
#include <stdio.h>  
// custom libraries are usxually clean as well
#include "bko.h"
// constants are next, along with structs
#include "constants.h"
#include "debug.h"
#include "subscripts.h"

// do C code headers last, this file.s header dead last.
#include "n2.h"
#include "text.h"
#include "graphics.h"

// my own header file is included dead last.  IT is MANDATORY!  
#include  "output.h"



static bool print_now(double elapsed)
{
        if(DEBUG) return true;
        return(elapsed == 0.0 || (int) elapsed > (int) (elapsed - DELTA_T));
}


void master_output(double elapsed, double ball[], double block[], double paddle[])
{
    if(TEXT)
    {
    	if(print_now(elapsed))master_print(elapsed, ball, block, paddle );
    }
    if(GRAPHICS)master_draw(elapsed, ball, block, paddle, true);

}

void final_output(double elapsed, double ball[], double block[], double paddle[])
{
    // may differ from master_output
    if(TEXT)master_print(elapsed, ball, block, paddle );
    if(GRAPHICS)freeze(elapsed, ball, block, paddle);
}

// various mesages
void bounce_message(int color, char *wall, double X, double Y)
{
    if(TEXT)printf("Ball %d bounces off %s, winding up at (%.2lf, %.2lf).\n", color, wall, X, Y);
    if(GRAPHICS)
    {
        char buf[80];
        sprintf(buf, "Ball %d bounces off %s, winding up at (%.2lf, %.2lf).", color, wall, X, Y);
        bko_status(buf);
    }
}

void scanf_message(char *who, int got, int wanted)
{
    if(TEXT)printf("ERROR: %s read %d of %d tokens.\n", who, got, wanted);
}

void bad_ball_message(double ball[])
{
    if(TEXT)printf("ERROR: Ball %d has a zero Y velocity.\n", (int) ball[SS_COLOR]);
}
