/* Chloe Feller */

#define MAX_STR_LENGTH 100
#define FIVE 5
#define THREE 3
#define FOUR 4
#define ZERO 0
#define D_ZERO 0.0
#define DELTA_ONE 1.0
#define DELTA_THIRTYTWO 32.0
#define TWO 2
#define ONE 1
