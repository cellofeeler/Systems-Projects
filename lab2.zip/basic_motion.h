/* Chloe Feller */

double basic_motion(double oldPosition, double velocity);
int main();
