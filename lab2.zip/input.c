/* Chloe Feller */

// system libraries first since they rarely have bugs
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// then custom libraries

// constants next
#include "constants.h"
#include "subscripts.h"
#include "debug.h"

// C code headers last
#include "lab2.h"
#include "output.h"
#include "graphics.h"

// this file's header file included dead last
#include "input.h" 

/*
 * Collect data for ball and store it.
 * For lab 2, function will skip to the final values.
 */
bool collect_ball(double ball[], FILE *fpter)
{

	// First collect number of balls...
	// Note: if scanf fails to read correctly, stop and indicate a failure
	int ballNum;
	char str[MAX_STR_LENGTH];
		
	fgets(str, MAX_STR_LENGTH, fpter); // skip first line
	fscanf(fpter, "%d", &ballNum);
	if (0 == ballNum)
	{
		if (TEXT)
		{
			printf("Unable to detect how many balls to be used.");
		}
		if (GRAPHICS) master_draw(ZERO, ball, ZERO, ZERO, false);
		return false;
	}

	/* Then use that number to loop and store ball data... 
	 * Note: skips to the last entry for lab 2 (although kept as a loop to hopefully use when
	 * multiple balls are used.)
	 * Note: if scanf fails to read the data or if VY is 0.0, stop and indicate a failure
	*/ 
	for (int i = 0; i < ballNum; i++)
	{
		if(FIVE != fscanf(fpter, "%lf %lf %lf %lf %lf", &ball[SS_COLOR], &ball[SS_X], &ball[SS_Y], &ball[SS_VX], &ball[SS_VY]))
		{
			scanf_message("ball", scanf("%lf %lf %lf %lf %lf", &ball[SS_COLOR], &ball[SS_X], &ball[SS_Y], &ball[SS_VX], &ball[SS_VY]), FIVE);
			return false;
		}
		else if (ball[SS_VY] == 0.0)
		{
			bad_ball_message(ball);
			return false;
		}
	}

	return true;
}

/*
 * Collect data for block and store it.
 * For lab 2, function will skip to the final values.
 */
bool collect_block(double block[], FILE *fptr)
{
	// First collect number of blocks...
	// Note: if scanf fails to read correctly, stop and indicate a failure
	int blockNum;
	char str[ONE];

	fgets(str, MAX_STR_LENGTH, fptr);
	fscanf(fptr, "%d", &blockNum);
	if (0 == blockNum)
	{
		if (TEXT)
		{
			printf("Unable to detect how many blocks to be used.");
		}
		if (GRAPHICS)
		{
			master_draw(ZERO, ZERO, block, ZERO, false);
		}
		return false;
	}

	/*
	 * Then use that number to loop and store block data...
	 * Note: skips to the last entry for lab 2
	 */
	for (int i = 0; i < blockNum; i++)
	{	
		if (THREE != fscanf(fptr, "%lf %lf %lf", &block[SS_COLOR], &block[SS_X], &block[SS_Y]))
		{
			scanf_message("block", scanf("%lf %lf %lf", &block[SS_COLOR], &block[SS_X], &block[SS_Y]), THREE);
			return false;
		}
	}

	return true;
}

/*
 * Collect data for paddle and store it.
 * For lab 2, function will skip to the final value.
 */
bool collect_paddle(double paddle[], FILE *fptr)
{
	// First collect number of paddles...
	// Note: if scanf fails to read correctly, stop and indicate a failure
	int paddleNum;
	char str[MAX_STR_LENGTH];

	fgets(str, MAX_STR_LENGTH, fptr); // skip first line
	fscanf(fptr, "%d", &paddleNum);
	if (0 == paddleNum)
	{
		if (TEXT)
		{
			printf("Unable to detect how many paddles to be used.");
		}
		if (GRAPHICS)
		{
			master_draw(ZERO, ZERO, ZERO, paddle, false);
		}
		
		return false;
	}

	/*
	 * Then use that number to loop and store paddle data...
	 * Note: skips to the last entry for lab 2
	 */
	for (int i = 0; i < paddleNum; i++)
	{
		if (THREE != fscanf(fptr, "%lf %lf %lf", &paddle[SS_COLOR], &paddle[SS_X], &paddle[SS_SIZE]))
		{
			scanf_message("paddle", scanf("%lf %lf %lf", &paddle[SS_COLOR], &paddle[SS_X], &paddle[SS_SIZE]), THREE);
			return false;
		}
	}

	return true;
}


/*
 * collects input from user
 */
bool collectInput(double ball[], double block[], double paddle[])
{
	FILE *fptr;
	char str[MAX_STR_LENGTH];

	// collect file name
	printf("Enter file name (no ./ needed): ");
	scanf("%s", str);

	fptr = fopen(str, "r");

	if (NULL == fptr)
	{
		if(TEXT)
		{
			printf("Could not open file. Exiting...");
			return false;
		}
		if(GRAPHICS)master_draw(ZERO, ball, block, paddle, false);
	}

	// collect ball, block, then paddle data
	if (1 != collect_ball(ball, fptr))
	{
		printf("Ball data was not inserted: cannot load sim.");
		return false;
	}
	else if (1 != collect_block(block, fptr))
	{
		printf("Block data was not inserted: cannot load sim.");
		return false;
	}
	else if (1 != collect_paddle(paddle, fptr))
	{
		printf("Paddle data was not inserted: cannot load sim.");
		return false;
	}


	return true;
}
