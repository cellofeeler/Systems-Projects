/* Chloe Feller */

double left_wall_collision(double x, double ball[], double boundary_value);
int main();
