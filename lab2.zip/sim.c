/* Chloe Feller */

// system libraries first since they rarely have bugs
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// then custom libraries

// C code headers last
#include "input.h"
#include "output.h"
#include "subscripts.h"
#include "constants.h"
#include "graphics.h"

// this file's header dead last
#include "sim.h"

#define BL_LENGTH 3.0
#define BL_HEIGHT 2.0
#define BOTTOM_FIELD 0.0
#define TOP_WALL 20.0
#define LEFT_WALL 0.0
#define RIGHT_WALL 30.0


/*
 * Executes the first step of updating the ball in the simulation: applying basic motion.
 */
double basic_motion(double oldPosition, double velocity)
{
	return oldPosition + (DELTA_T * velocity);
}

/*
 * Executed when the ball experiences a left collision.
 */
double left_collision(double x, double ball[], double boundary_value)
{
	x = TWO * boundary_value - x;
	ball[SS_VX] = -ball[SS_VX];

	return x;
}



/*
 * Executes when the ball experiences a right collision.
 */
double right_collision(double x, double ball[], double boundary_value)
{
	x = TWO * boundary_value - x;
	ball[SS_VX] = -ball[SS_VX];

	return x;
}

/*
 * Executes when the ball experiences an up/down collision.
 */
double up_down_collision(double y, double ball[], double boundary_value)
{
	y = TWO * boundary_value - y;
	ball[SS_VY] = -ball[SS_VY];

	return y;
}

/*
 * Checks if a left collision has occurred on a block. 
 */
bool block_left(double oldX, double oldY, double ball[], double block[])
{
	// first simple rejection
	if (ball[SS_VX] > ZERO)
	{
		// second simple rejection
		if (oldX < block[SS_X])
		{
			// intersection test
			if ((block[SS_Y] - ONE) < oldY < (block[SS_Y] + ONE))
			{
				left_collision(oldX, ball, block[SS_X]);
				bounce_message(ball[SS_COLOR], "block left side", ball[SS_X], ball[SS_Y]);
				return true;
			}
		}
	}


	return false;
}

/*
 * Checks if a right collision has occurred on a block.
 */
bool block_right(double oldX, double oldY, double ball[], double block[])
{
	// first simple rejection
	if (ball[SS_VY] < ZERO)
	{
		// second simple rejection
		if (block[SS_X] <= oldX <= (block[SS_X] + TWO))
		{
			// intersection test
			if (oldY >= block[SS_Y] + ONE || oldY <= block[SS_Y])
			{
				right_collision(oldX, ball, block[SS_X]);
				bounce_message(ball[SS_COLOR], "block right side", ball[SS_X], ball[SS_Y]);
				return true;
			}
		}
	}

	return false;

}

/*
 * Enacts a top block collision.
 */ 
void block_up(double oldX, double oldY, double ball[], double block[])
{
	if (block[SS_Y] <= oldY <= block[SS_Y] + ONE)
	{
		if (oldX >= block[SS_X] + ONE || oldX <= block[SS_X])
		{
			up_down_collision(oldY, ball, block[SS_Y]);
			bounce_message(ball[SS_COLOR], "block top side", ball[SS_X], ball[SS_Y]);
		}
	}
}

/*
 * Enacts a bottom block collision.
 */
void block_down(double oldX, double oldY, double ball[], double block[])
{
	up_down_collision(oldY, ball, block[SS_Y]);
	bounce_message(ball[SS_COLOR], "block bottom side", ball[SS_X], ball[SS_Y]);
}


/*
 * Checks the position of the ball after basic motion is applied to see if any collisions
 * were made with a wall.
 */
void wall_collision(double ball[])
{
	if (ball[SS_X] < LEFT_WALL)

	{
		ball[SS_X] = left_collision(ball[SS_X], ball, LEFT_WALL);
		bounce_message(ball[SS_COLOR], "left wall", ball[SS_X], ball[SS_Y]);
	}
	else if (ball[SS_X] > RIGHT_WALL)
	{
		ball[SS_X] = right_collision(ball[SS_X], ball, RIGHT_WALL);
		bounce_message(ball[SS_COLOR], "right wall", ball[SS_X], ball[SS_Y]);
	}
	else if (ball[SS_Y] > TOP_WALL)
	{
		ball[SS_Y] = up_down_collision(ball[SS_Y], ball, TOP_WALL);
		bounce_message(ball[SS_COLOR], "top wall", ball[SS_X], ball[SS_Y]);
	}
}
	
/*
 * Executes the changes on the ball whenever a paddle collision occurs.
 * Changes include:
 * - Ball takes on the color of the paddle
 * - The usual changes for an up/down collision
 */
void paddle_collision(double ball[], double paddle[])
{
	double paddle_side = paddle[SS_X] + paddle[SS_SIZE];

	if ((ball[SS_Y] < BOTTOM_FIELD) && (-paddle_side < ball[SS_X] < paddle_side))
	{
		ball[SS_COLOR] = paddle[SS_COLOR];
		ball[SS_Y] = up_down_collision(ball[SS_Y], ball, BOTTOM_FIELD);
		bounce_message(ball[SS_COLOR], "paddle", ball[SS_X], ball[SS_Y]);
	}
}

/*
 * Executes the changes on the ball whenever a block collision occurs.
 */
int block_collision(double ball[], double block[])
{
	/* First check if ONE of the four conditions are true:
	 * If ball[SS_X] < block[SS_X]
	 * If ball[SS_X] > block[SS_X]
	 * If ball < block[SS_Y]
	 * If ball > block[SS_Y]
	 * If one is true, then the ball did not collide and this case can be ignored.
	 */
	if (((ball[SS_X] >= block[SS_X]) && (ball[SS_X] < (block[SS_X] + FOUR))) && ((ball[SS_Y] >= block[SS_Y]) && ball[SS_Y] < (block[SS_Y] + ONE)))
	{
		/* Next, need to deal with classifying the collision.
		 * Do left/right cases first, then up/down
		 */
		double oldX = ball[SS_X] - DELTA_T * ball[SS_VX];
		double oldY = ball[SS_Y] - DELTA_T * ball[SS_VY];

		if (block_left(oldX, oldY, ball, block))
		{
			return ONE;	
		}
		else if (block_right(oldX, oldY, ball, block))
		{
			return ONE;
		}
		else
		{
			if (ball[SS_VY] < ZERO)
			{
				block_up(oldX, oldY, ball, block);
			}
			else
			{
				block_down(oldX, oldY, ball, block);
			}

			return ONE;
		}
	}

	return ZERO;
}

/*
 * Updates the ball by applying basic motion and then checking for 
 * any collisions with blocks, walls, or paddles.
 */
void update_ball(double ball[], double paddle[], double block[])
{

	// apply basic motion
	ball[SS_X] = basic_motion(ball[SS_X], ball[SS_VX]);
	ball[SS_Y] = basic_motion(ball[SS_Y], ball[SS_VY]);

	// correct for any possible collisions with blocks
	block_collision(ball, block);
	
	// correct for any possible collisions with walls
	wall_collision(ball);
	
	// correct for any possible collisions with paddles
	paddle_collision(ball, paddle);

}

/*
 * Function that runs for as long as the sim does. Returns a false value if bad input was given
 * by the user.
 */
bool do_everything()
{
	bool ballOnField;
	int elapsed;
	double ball[FIVE], block[THREE], paddle[FOUR] = {0.0};

	if (1 == collectInput(ball, block, paddle))
	{
		ballOnField = true;
		elapsed = 0;
	}
	else
	{
		printf("Received bad input. Exiting program...");
		return false;
	}

	while (ballOnField)
	{	
		// first output the state of the simulation
		master_output(elapsed, ball, block, paddle);
	
		// then update the elapsed time
		elapsed += DELTA_T;
		// then update the ball
		update_ball(ball, paddle, block);

		if (ball[SS_Y] < BOTTOM_FIELD)
		{
			break;
		}
		
	}


	final_output(elapsed, ball, block, paddle);



	return true;


}

