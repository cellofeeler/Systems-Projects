/* Chloe Feller */
#include "subscripts.h"

#define DELTA_T (DELTA_ONE/DELTA_THIRTYTWO)
#define SS_COLOR ZERO
#define SS_SIZE TWO
#define SS_SCORE ONE
#define SS_X ONE
#define SS_Y TWO
#define SS_VX THREE
#define SS_VY FOUR
