/* Chloe Feller */

void freeze(double elapsed, double ball[], double block[], double paddle[]);
void master_draw(double elapsed, double ball[], double block[], double paddle[], bool show_balls);
