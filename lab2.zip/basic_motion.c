/* Chloe Feller */
#include <stdio.h>
#include "constants.h"

double basic_motion(double oldPosition, double velocity)
{
	double newPosition = oldPosition + (DELTA_T * velocity);
	printf("%.1lf\n", newPosition);
	return newPosition;
}



int main()
{
	double oldPosition, velocity;
	
	// test 1
	oldPosition = 1.0;
	velocity = 32.0;
	double new = basic_motion(oldPosition, velocity);
	printf("newPosition = 2.0\n");


	// test 2
	oldPosition = 4.0;
	velocity = 16.0;
	new = basic_motion(oldPosition, velocity);
	printf("newPosition = 4.5\n");

	r
eturn 1;
}
