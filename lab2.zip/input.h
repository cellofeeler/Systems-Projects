/* Chloe Feller */

bool collectInput(double ball[], double block[], double paddle[]);
bool collect_ball(double ball[], FILE *fpter);
bool collect_block(double block[], FILE *fptr);
bool collect_paddle(double paddle[], FILE *fptr);
