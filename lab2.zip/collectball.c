/* Chloe Feller */
#include <stdio.h>
#include <stdlib.h>

#include "constants.h"
#include "subscripts.h"


int collect_ball(double ball[], FILE *fpter)
{
	// First collect number of balls...
	// Note: if scanf fails to read correctly, stop and indicate a failure
	int ballNum;

	fgetc(fpter); // skip first line
	fscanf(fpter, "%d", &ballNum);
	if (0 == ballNum)
	{
		printf("Unable to detect how many balls to be used.");
		return 0;
	}
	else
	{
		printf("Number of balls: %d\n", ballNum);
	}

	/*
	 * Then use that number to loop and store ball data...
	 * Note: skips the last entry for lab 2
	 * Note: if scanf fails to read the data or if VY is 0.0, stop and indicate a failure
	 */
	for (int i = 0; i < ballNum; i++)
	{
		if (FIVE != fscanf(fpter, "%lf %lf %lf %lf %lf", &ball[SS_COLOR], &ball[SS_X], &ball[SS_Y], &ball[SS_VX], &ball[SS_VY]))
		{
			printf("Could not store all 5 numbers as data.\n");
			return 0;
		}
		else if (ball[SS_VY] == 0.0)
		{
			printf("VY cannot be 0.0.");
			return 0;
		}
	}

	// print the values to make sure prototype did its job correctly
	printf("%.1lf %.1lf %.1lf %.1lf %.1lf\n", ball[SS_COLOR], ball[SS_X], ball[SS_Y], ball[SS_VX], ball[SS_VY]);


	return 1;
}

int main()
{
double ball[FIVE] = {0.0};
FILE *fpter;
char str[MAX_STR_LENGTH];

printf("Enter file name: ");
scanf("%s", str);

fpter = fopen(str, "r");
collect_ball(ball, fpter);

printf("Values should be: 3 25.0 17.0 8.0 4.0 for x2.bkf");



}


