/* Chloe Feller */
#include <stdlib.h>
#include <stdio.h>

#include "constants.h"


double left_wall_collision(double x, double ball[], double boundary_value)
{
	x = (2 * boundary_value) - x;
	ball[SS_VX] = 0.0;
	
	return x;

}



int main()
{
	double ball[5] = {0.0};
	const double left_boundary = 0.0;
	double x;

	// test 1
	x = -5.0;
	ball[SS_VX] = 1.5;

	x = left_wall_collision(x, ball, left_boundary);
	
	printf("x value should be: 5.0\nx value is: %.1lf\nvelocity should be 0.0\nvelocity is: %.1lf\n\n", x, ball[SS_VX]);
	

	// test 2
	x = -15.0;
	ball[SS_VX] = -7.5;

	x = left_wall_collision(x, ball, left_boundary);

	printf("x value should be: 15.0\nx value is: %.1lf\nvelocity should be 0.0\nvelocity is: %.1lf\n", x, ball[SS_VX]);


	return 1;	
}
