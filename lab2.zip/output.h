/* Chloe Feller */

void bad_ball_message(double ball[]);
void bounce_message(int color, char *wall, double X, double Y);
void final_output(double elapsed, double ball[], double block[], double paddle[]);
void master_output(double elapsed, double ball[], double block[], double paddle[]);
void scanf_message(char *who, int got, int wanted);
