/* Chloe Feller */

// system libraries first since they rarely have bugs
#include <stdio.h>

// custom libraries next

// then constants and structs
#include "constants.h"
#include "debug.h"
#include "subscripts.h"

// C code headers last...
#include "output.h"
// with this file's header being dead last.
#include "text.h"

void master_print(double elapsed, double ball[], double block[], double paddle[])
{
	printf("\n");
	printf("Elapsed time: %5lf\n", elapsed);
	printf("Ball %lf is at (%.5lf, %.5lf) with velocity (%.5lf, %.5lf).\n", ball[SS_COLOR], ball[SS_X], ball[SS_Y], ball[SS_VX], ball[SS_VY]);
	printf("Block %lf is at (%.5lf, %.5lf).\n", block[SS_COLOR], block[SS_X], block[SS_Y]);
	printf("Paddle %lf is at %.5lf, size %.2lf with score %lf.\n", paddle[SS_COLOR], paddle[SS_X], paddle[SS_SIZE], paddle[SS_SCORE]);

}
