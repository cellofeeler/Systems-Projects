/* Chloe Feller */

void master_print(double elapsed, double ball[], double block[], double paddle[]);
