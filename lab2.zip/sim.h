/* Chloe Feller */

double basic_motion(double oldPosition, double velocity);
int block_collision(double ball[], double block[]);
void block_down(double oldX, double oldY, double ball[], double block[]);
bool block_left(double oldX, double oldY, double ball[], double block[]);
bool block_right(double oldX, double oldY, double ball[], double block[]);
void block_up(double oldX, double oldY, double ball[], double block[]);
bool do_everything();
double left_collision(double x, double ball[], double boundary_value);
void paddle_collision(double ball[], double paddle[]);
double right_collision(double x, double ball[], double boundary_value);
double up_down_collision(double y, double ball[], double boundary_value);
void update_ball(double ball[], double paddle[], double block[]);
void wall_collision(double ball[]);
