/* Chloe Feller */

int collect_ball(double ball[], FILE *fpter);
int main();
