/* Chloe Feller */

int divide( int x, int y);
int main();
void quotient_table(int limit);
