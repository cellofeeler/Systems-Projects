/* Chloe Feller */

// system libraries first since they rarely have bugs
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// then custom libraries
#include "structs.h"
#include "libll.h"

// constants next
#include "constants.h"
#include "subscripts.h"
#include "debug.h"

// C code headers last
#include "lab2.h"
#include "memory.h"
#include "output.h"

// this file's header file included dead last
#include "input.h" 

/* ComparisonFunction which compares the two given Y positions, and returns true if the first Y belongs 
 * earlier than the second
 */
static bool compare_balls(void *first_ball, void *second_ball)
{
	bool above;

	if(DEBUG)printf("DEBUG SORT: Assigning void pointers to Ball structs...\n");
	struct Ball *ball_one = first_ball, *ball_two = second_ball;

	if(DEBUG)printf("DEBUG SORT: Comparing %lf and %lf...\n", ball_one->y_position, ball_two->y_position);
	return above = ((ball_one->y_position) >= (ball_two->y_position));
}

/* inserts a ball's data into the ball linked list
 */
static bool insert_balls(struct Sim *simulation, struct Ball *ball)
{
	bool added;
	
	if(!(added = insert(&(simulation->bounce), ball, compare_balls, TEXT)))
	{
		printf("Not Added :(\n");
		added = false;
	}

	return added;
}

/*
 * Read data for ball
 */
static void *read_ball(struct Sim *simulation)
{

	// First collect number of balls...
	// Note: if scanf fails to read correctly, indicate a failure but KEEP GOING
	int ballNum, temp;
	struct Ball ball, *ptrBall = &ball, *allocated;
		
	if (ONE != (temp = scanf("%d", &ballNum)))
	{
		scanf_message("read_ball", temp, ONE);
	}

	// Then use that number to loop and store ball data...  
	for (int i = ZERO; i < ballNum; i++)
	{
		// scan ball info in
		if(FIVE == (temp = scanf("%d %lf %lf %lf %lf", &(ball.color), &(ball.x_position), &(ball.y_position), &(ball.x_velocity), &(ball.y_velocity))))
		{
			// allocate memory to insert ball info. if memory is not allocated, ball info will not be added
			if(allocated = allocate_thing(FIVE, ball.color))
			{
				allocated = &ball;
				if(!insert_balls(simulation, allocated))
				{
					printf("Ball %d was not added.\n", (ball.color));
				}
			}
		}
	}

	return allocated;
}

/*compare the Y and X values of the blocks (X value only compared when Y values are equal), and return true if
 * data_one belongs earlier than data_two
 */
static bool compare_blocks(void *data_one, void *data_two)
{
	bool above;

	if(DEBUG)printf("DEBUG SORT: Assigning void pointers to block structs...\n");
	struct Block *block_one = data_one, *block_two = data_two;

	if(DEBUG)printf("DEBUG SORT: Comparing %lf and %lf...\n", block_one->y_position, block_two->y_position);
	if((block_one->y_position == block_two->y_position))
	{
		return above = ((block_one->x_position) > (block_two->x_position));
	}
	else
	{
		return above = ((block_one->y_position) > (block_two->x_position));
	}

	
}

/* Insert block data, return false if not added.
 */
static bool insert_blocks(struct Sim *simulation, struct Block *block)
{
	bool added = true;

	if (!(added = insert(&(simulation->obstacle), block, compare_blocks, TEXT)))
	{
		printf("Not Added :(\n");
		added = false;
	}

	return added;
}

/*
 * Read ball data.
 */
static void *read_block(struct Sim *simulation)
{
	// First collect number of blocks...
	// Note: if scanf fails to read correctly, indicate a failure but KEEP GOING
	int blockNum, temp;
	struct Block block, *ptrBlock = &block, *allocated;

	if (ONE != (temp = scanf("%d", &blockNum)))
	{
		scanf_message("read_block", temp, ONE);
	}

	/*
	 * Then use that number to loop and store block data...
	 */
	for (int i = ZERO; i < blockNum; i++)
	{
		// scan block info in
		if (THREE == (temp = scanf("%d %lf %lf", &(block.color), &(block.x_position), &(block.y_position))))
		{
			// allocate memory to insert block info
			if(allocated = allocate_thing(THREE, block.color))
			{
				allocated = ptrBlock;
				if(!insert_blocks(simulation, ptrBlock))
				{
					printf("Block %d was not inserted.\n", (block.color));
				}
			}
		}
	}

	return allocated;
}

/* Insert paddle data, return false if not inserted.
 */
static bool insert_paddles(struct Sim *simulation, struct Paddle *paddle, const int paddleNum)
{
	bool added;

	if(ZERO > (paddle->size) || (ZERO >= (paddle->color) > SEVEN))
	{
		printf("Paddle info is not correct.\nPaddle color: %d\nPaddle size: %lf\n", paddle->color, paddle->size);
	}
	else
	{
		printf("DEBUG: Inserting paddle %d...\n", paddleNum);
		(simulation->paddles)[paddleNum] = paddle;
	}

	return added;

}

/*
 * Read paddle data.
 */
static void read_paddle(struct Sim *simulation)
{
	// First collect number of paddles...
	// Note: if scanf fails to read correctly, indicate a failure but KEEP GOING
	const int paddleNum; 
	int temp;
	struct Paddle paddle, *ptrPaddle = &paddle;

	if (ONE != (temp = scanf("%d", &(paddle.paddleNum))))
	{
		scanf_message("read_paddle", temp, ONE);
	}

	/*
	 * Then use that number to loop and store paddle data...
	 */
	for (int i = ZERO; i < (paddle.paddleNum); i++)
	{
		if (THREE == (temp = scanf("%d %lf %lf", &(paddle.color), &(paddle.x_position), &(paddle.size))))
		{
			if(!insert_paddles(simulation, ptrPaddle, (i + ONE)))
			{
				printf("Paddles not inserted.\n");
			}
		}
	}
}

/*
 * collects input from user
 */
bool collectInput(struct Ball *ball, struct Block *block, struct Paddle *paddle, struct Sim *simulation)
{
	// collect ball, block, then paddle data
	read_ball(simulation);
	read_block(simulation);
	(simulation);

	return true;
}

