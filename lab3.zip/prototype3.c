/* Chloe Feller */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "debug.h"
#include "libll.h"
#include "structs.h"
#include "constants.h"
#include "subscripts.h"

/* uses a ComparisonFunction to compare the first letters of two strings, and return true if the 
 * first string belongs before the second.
 */
bool first_letter(void *firstStr, void *secondStr)
{
	bool above;
	char first[MAX_STR_LENGTH], second[MAX_STR_LENGTH];

	strcpy(first, firstStr);
	strcpy(second, secondStr);
	
	return above = (first[ZERO] < second[ZERO]);
}

// uses an ActionFunction to print the given void pointer
void string_print(void *param)
{
	char *string = param;
	printf("%s\n", string);
}

// inserts strings into a linked list and sorts them in alphabetical order
void insert_stuff(void *list, char *strings[])
{
	bool added;
	
	list = NULL;

	for(int i = ZERO; i < FIVE; i++)
	{
		if(!(added = insert(&list, strings[i], first_letter, ONE)))
		{
			printf("Not Added :(\n");
		}
		else
		{
			printf("Added! :)\n");
		}
	}

	sort(list, first_letter);

	iterate(list, string_print);
}

int main()
{
	void *list;

	char *strings_test_1[FIVE] = {"Go Bucks!", "OH!", "IO!", "Corn", "Beans"};
	insert_stuff(list, strings_test_1);

	return ONE;
}

