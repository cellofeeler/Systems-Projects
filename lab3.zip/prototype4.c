/* Chloe Feller */
#include <stdbool.h>

#include "structs.h"
#include "constants.h"

#include "input.h"

#include "prototype4.h"

int main()
{
	struct Ball throw, *ball = &throw;
	struct Block wall, *block = &wall;
	struct Paddle stroke, *paddle = &stroke;
	struct Sim sim, *simulation = &sim;

	void *ballList = (ball->game->bounce);

	bool input = collectInput(ball, block, paddle, simulation);

	return ONE;
}

