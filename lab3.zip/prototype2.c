/* Chloe Feller */

#include <stdlib.h>
#include <stdio.h>

#include "debug.h"
#include "constants.h"
#include "structs.h"

// Allocate memory for either the ball or the block struct.
void allocate_thing(int n, int objectNum)
{
	void *allocate;

	// allocate memory for the ball
	allocate = malloc(n * (sizeof(allocate)));

	if (NULL == allocate)
	{
		if(TEXT)
		{
			printf("DIAGNOSTIC: allocate_thing: NO bytes allocate for object #%d\n", objectNum);
		}
	}
	else
	{
		if(TEXT)printf("DIAGNOSTIC: allocate_thing: %d bytes allocated for object #%d\n", (n * EIGHT), objectNum);
		if(DEBUG)printf("DEBUG: allocate_thing: returning %p\n", allocate);
	}
}

int p2main()
{
	int size = FIVE;
	int object = FOUR;

	allocate_thing(size, object);	

	return 1;
}

