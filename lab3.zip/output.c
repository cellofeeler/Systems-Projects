/* Copyringht  2024 Neil Kirby not for disclosure wiothout permission
 * Note: Much of the code in this file is copyrighted to Neil Kirby,
 * it is just a combination of text.c, graphics.c, and output.c.
 * I commented where the start of each file is to help both me and (hopefully) the graders
 * easily find stuff.
 * Chloe Feller
 */

// system libraries rarely have bugs, do them first
#include <stdbool.h>
#include <stdio.h>  
// custom libraries are usxually clean as well
#include "bko.h"
#include "libll.h"
// constants are next, along with structs
#include "constants.h"
#include "debug.h"
#include "subscripts.h"
#include "structs.h"

// do C code headers last, this file.s header dead last.
#include "n2.h"

// my own header file is included dead last.  IT is MANDATORY!  
#include  "output.h"

// Start of text.c code, all made by Chloe Feller
// print the position and velocity of the given ball
void print_balls(void *data)
{
	const struct Ball *ball = data;
	printf("Ball %d is at (%.5lf, %.5lf) with velocity (%.5lf, %.5lf).\n", ball->color, ball->x_position, ball->y_position, ball->x_velocity, ball->y_velocity);
}

// print the position of the given block
void print_blocks(void *data)
{
	const struct Block *block = data;
	printf("Block %d is at (%.5lf, %.5lf).\n", block->color, block->x_position, block->y_position);
}

// print the position, size, and score of the given paddle
void print_paddles(const struct Paddle *paddle)
{
	printf("Paddle %d is at %.5lf, size %.2lf with score %d.\n", paddle->color, paddle->x_position, paddle->size, paddle->score);
}

// print elapsed time, balls, blocks, and paddles info
static void master_print(const struct Sim *simulation, const struct Paddle *paddle, const struct Ball *ball)
{
	printf("\n");
	printf("Elapsed time: %5lf\n", simulation->elapsed);
	printf("Balls:\n");
	iterate(simulation->bounce, print_balls);

	printf("Blocks:\n");
	iterate(simulation->obstacle, print_blocks);

	for(int i = ZERO; i < paddle->paddleNum; i++)
	{
		print_paddles(simulation->paddles[i]);
	}
}

// Start of graphics.c code, all made by Neil Kirby

// print balls on the screen while game is running
static void draw_balls(const struct Ball *ball)
{
	bko_ball((int) ball->color, ball->x_position, ball->y_position);
}

// print blocks on the screen while game is running
static void draw_blocks(const struct Block *block)
{
	bko_block((int) block->color, block->x_position, block->y_position);
}

// print paddles on the screen while game is running 
static void draw_paddles(const struct Paddle *paddle)
{
	bko_paddle((int) paddle->color, (int) paddle->score, paddle->x_position, paddle->size);
}

// boot up the graphics side of the game
void master_draw(double elapsed, const struct Ball *ball, const struct Block *block, const struct Paddle *paddle, bool show_balls)
{
	bko_clear();
	bko_sim_time((int) (elapsed * 1000));
	if(show_balls)draw_balls(ball);
	draw_blocks(block);
	draw_paddles(paddle);
	bko_refresh();
	microsleep((int) (DELTA_T * 1000000));
}

// pause the game in its current state
void freeze(double elapsed, const struct Ball *ball, const struct Block *block, const struct Paddle *paddle)
{
	for(double d = 0.0; d < 4.0; d += DELTA_T)
	{
		master_draw(elapsed, ball, block, paddle, false);
	}
}

// Start of output.c code, all made by Neil Kirby
// one-job comments added by Chloe Feller

// check to see if we can print
static bool print_now(double elapsed)
{
        if(DEBUG) return true;
        return(elapsed == 0.0 || (int) elapsed > (int) (elapsed - DELTA_T));
}

// changed master_output to a void function that takes a pointer to a Sim, a pointer to a Ball, a pointer to a Block, and a pointer to a Paddlei
// output what is going on in the game (graphics or sim)
void master_output(const struct Sim *simulation, const struct Ball *ball, const struct Block *block, const struct Paddle *paddle)
{
    if(TEXT)
    {
    	if(print_now(simulation->elapsed))master_print(simulation, paddle, ball);
    }
    if(GRAPHICS)master_draw(simulation->elapsed, ball, block, paddle, true);

}

// changed final_output to a void function which takes a const pointer to a Sim struct, a const pointer to a Ball struct, a const pointer to a Block struct, and a const pointer to a Paddle struct
// final output info when the game ends
void final_output(struct Sim *simulation, const struct Ball *ball, const struct Block *block, const struct Paddle *paddle)
{
    // may differ from master_output
    if(TEXT)master_print(simulation, paddle, ball);
    if(GRAPHICS)freeze(simulation->elapsed, ball, block, paddle);
}

// various mesages

// message for when a ball bounces off of something
void bounce_message(int color, const char *wall, double X, double Y)
{
    if(TEXT)printf("Ball %d bounces off %s, winding up at (%.2lf, %.2lf).\n", color, wall, X, Y);
    if(GRAPHICS)
    {
        char buf[80];
        sprintf(buf, "Ball %d bounces off %s, winding up at (%.2lf, %.2lf).", color, wall, X, Y);
        bko_status(buf);
    }
}

// message for when a scanf() error occurs
void scanf_message(const char *who, int got, int wanted)
{
    if(TEXT)printf("ERROR: %s read %d of %d tokens.\n", who, got, wanted);
}

// message for when bad ball info is given
void bad_ball_message(const struct Ball *ball)
{
    if(TEXT)printf("ERROR: Ball %d has a zero Y velocity.\n", (int) ball->color);

}
