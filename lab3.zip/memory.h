/* Chloe Feller */

void *allocate_thing(int n, int objectNum);
void free_thing(void *thing);
