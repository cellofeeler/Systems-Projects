/* Chloe Feller */

bool Y_compare(void *first_y, void *second_y);
bool do_everything();
