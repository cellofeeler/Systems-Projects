/* Chloe Feller */

void allocate_thing(int n, int objectNum);
int p2main();
