/* Chloe Feller */
#include "subscripts.h"

#define DELTA_T (DELTA_ONE/DELTA_THIRTYTWO)
