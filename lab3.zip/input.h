/* Chloe Feller */

bool collectInput(struct Ball *ball, struct Block *block, struct Paddle *paddle, struct Sim *simulation);
