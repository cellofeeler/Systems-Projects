/* Chloe Feller */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "structs.h"
#include "libll.h"

#include "memory.h"

#include "prototype5.h"

// compares the Y values in the given structs
static bool Y_compare(void *first_ball, void *second_ball)
{
	bool above;
	struct Ball *ball_one = first_ball, *ball_two = second_ball;

	return above = (&(ball_one->y_position) > &(ball_two->y_position));
}

// ActionFunction that prints ball info
static void print_stuff(void *first_ball)
{
	char *ball_one = first_ball;
	printf("%s\n", ball_one);
}

//
static int y_compare_test(struct Ball *ball, struct Ball *ball_two)
{
	// check that the Y_compare functions works properly
	bool switched = Y_compare(ball, ball_two);

	// 1 printed if b y_position belongs in front of b_two y_position
	printf("%d: %lf > %lf\n", switched, ball->y_position, ball_two->y_position);

	switched = Y_compare(ball_two, ball);

	// should print 0 since b_two y_position is not greater than b_one's
	printf("%d: %lf > %lf\n", switched, ball_two->y_position, ball->y_position);

	return ONE;
}

// inserts a ball's data into the ball linked list
static bool insert_ball(struct Ball *ball)
{
	bool added;
	struct Sim si, *simulation = &si;
	allocate_thing(FIVE, ball->color);
	allocate_thing(ONE, ZERO);

	if(!(added = insert(&(ball->game), ball, Y_compare, ONE)))
	{
		printf("Not added :(\n");
	}

	return added;
}

// test the insert_ball function
static bool insert_balls_test(struct Ball *ball, struct Ball *ball_two)
{
	bool added;
	
	added = insert_ball(ball);
	if(added)printf("ball was added!\n");
	added = insert_ball(ball_two);
	if(added)printf("ball_two was added!\n");

	iterate(ball, print_stuff);

	return added;
}


// overall this prototype is testing the insert sequence of multiple balls
int main()
{
	struct Ball b, b_two;
	struct Ball *ball = &b;
	struct Ball *ball_two = &b_two;
	bool added;

	b.y_position = EIGHT;
	b_two.y_position = FOUR;

	y_compare_test(ball, ball_two);

	// initializing both struct Balls so no memory issues occur
	(ball->x_position = ZERO), (ball->x_velocity = ZERO), (ball->y_velocity = ZERO);
	(ball_two->x_position = ZERO), (ball_two->x_velocity = ZERO), (ball_two->y_velocity = ZERO);

	insert_balls_test(ball, ball_two);


	return ONE;
}


