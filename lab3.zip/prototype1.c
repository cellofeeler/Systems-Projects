/* Chloe Feller */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#include "structs.h"
#include "constants.h"

#include "prototype2.h"

#include "prototype1.h"

// Reads the data from the ball in following the criteria in the lab.
static struct Ball *read_ball()
{
	// First collect number of balls...
	int ballNum, temp;
	struct Ball ball;
	struct Ball *b;

	if (ONE != (temp = scanf("%d", &ballNum)))
	{
		printf("Bad ball number.\n");
	}

	// Then store the number of balls
	for (int i = 0; i < ballNum; i++)
	{
		if (FIVE != (temp = scanf("%d %lf %lf %lf %lf", &(ball.color), &(ball.x_position), &(ball.y_position), &(ball.x_velocity), &(ball.y_velocity))))
		{
			printf("Only read %d balls of %d", temp, FIVE); // replace with scanfmessage function
		}
		else if (D_ZERO == ball.y_velocity)
		{
			printf("y-velocity cannot be zero.");
		}
	}

	allocate_thing(FIVE, ball.color);

	b = &ball;

	return b;
}

int main()
{
	struct Ball *ball = read_ball();
	
	printf("%d %lf %lf %lf %lf", (ball->color), (ball->x_position), (ball->y_position), (ball->x_velocity), (ball->y_velocity));
	return 1;
}

