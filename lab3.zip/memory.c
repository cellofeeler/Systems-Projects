/* Chloe Feller */
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

#include "debug.h"
#include "structs.h"
#include "constants.h"
#include "output.h"

#include "memory.h"

// Allocate memory for either the ball or block struct.
// Note n is used to differentiate between the differing amount of memory to allocate in the two structs
void *allocate_thing(int n, int objectNum)
{
	void *allocate;

	// allocate memory
	allocate = malloc(n * (sizeof(allocate)));

	if (NULL == allocate)
	{
		if(TEXT)
		{
			printf("DIAGNOSTIC: allocate_thing: NO bytes allocated for object #%d\n", objectNum);
		}
	}
	else
	{
		if(TEXT)printf("DIAGNOSTIC: allocate_thing: %d bytes allocated for object %d\n", (n * EIGHT), objectNum);
		if(DEBUG)printf("DEBUG: allocate_thing: returning %p\n", allocate);
	}

	return allocate;
}

// Free memory, giving diagnostics and debugs
void free_thing(void *thing)
{
	static int objects = ZERO;
	printf("DEBUG: free_thing: freeing %p", thing);
	fflush(stdout);
	free(thing);
	objects++;
	printf("DIAGNOSTIC: free_thing: %d objects freed", objects);
	
}

