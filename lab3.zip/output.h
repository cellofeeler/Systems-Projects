/* Chloe Feller */

void bad_ball_message(const struct Ball *ball);
void bounce_message(int color, const char *wall, double X, double Y);
void final_output(struct Sim *simulation, const struct Ball *ball, const struct Block *block, const struct Paddle *paddle);
void freeze(double elapsed, const struct Ball *ball, const struct Block *block, const struct Paddle *paddle);
void master_draw(double elapsed, const struct Ball *ball, const struct Block *block, const struct Paddle *paddle, bool show_balls);
void master_output(const struct Sim *simulation, const struct Ball *ball, const struct Block *block, const struct Paddle *paddle);
void print_balls(void *data);
void print_blocks(void *data);
void print_paddles(const struct Paddle *paddle);
void scanf_message(const char *who, int got, int wanted);
