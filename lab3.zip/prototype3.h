/* Chloe Feller */

bool first_letter(void *firstStr, void *secondStr);
void insert_stuff(void *list, char *strings[]);
int main();
void string_print(void *param);
