/* I AM GETTING A 0 ON THIS LAB */

bool Y_compare(void *first_y, void *second_y);
bool always_true(void *data, void *helper);
bool do_everything(char *file);
