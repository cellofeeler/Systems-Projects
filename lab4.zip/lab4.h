/* I AM GETTING A 0 ON THIS LAB */

bool init(int count);
int main(int argc, char *argv[]);
void teardown();
