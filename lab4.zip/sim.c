/* Chloe Feller */

// system libraries first since they rarely have bugs
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// then custom libraries
#include "libll.h"

// then constants
#include "structs.h"
#include "constants.h"
#include "subscripts.h"
#include "debug.h"

// C code headers last
#include "input.h"
#include "output.h"
#include "memory.h"

// this file's header dead last
#include "sim.h"

#define BL_LENGTH 3.0
#define BL_HEIGHT 2.0
#define BOTTOM_FIELD 0.0
#define TOP_WALL 20.0
#define LEFT_WALL 0.0
#define RIGHT_WALL 30.0

bool Y_compare(void *first_y, void *second_y)
{
	bool above;
	double *first = first_y;
	double *second = second_y;

	return above = (first < second);
}


/*
 * Executes the first step of updating the ball in the simulation: applying basic motion.
 */
static double basic_motion(double oldPosition, double velocity)
{
	return oldPosition + (DELTA_T * velocity);
}

/*
 * Executed when the ball experiences a left collision.
 */
static double left_collision(double x, struct Ball *ball, double boundary_value)
{
	x = TWO * boundary_value - x;
	ball->x_velocity = -ball->x_velocity;

	return x;
}



/*
 * Executes when the ball experiences a right collision.
 */
static double right_collision(double x, struct Ball *ball, double boundary_value)
{
	x = TWO * boundary_value - x;
	ball->x_velocity = -ball->x_velocity;

	return x;
}

/*
 * Executes when the ball experiences an up/down collision.
 */
static double up_down_collision(double y, struct Ball *ball, double boundary_value)
{
	y = TWO * boundary_value - y;
	ball->y_velocity = -ball->y_velocity;

	return y;
}

/*
 * Checks if a left collision has occurred on a block. 
 */
static bool block_left(double oldX, double oldY, struct Ball *ball, struct Block *block)
{
	// first simple rejection
	    if (ball->x_velocity > ZERO)
	{
		// second simple rejection
		if (oldX < block->x_position)
		{
			// intersection test
			if ((block->y_position - ONE) < oldY < (block->y_position + ONE))
			{
				left_collision(oldX, ball, block->x_position);
				bounce_message(ball->color, "block left side", ball->x_position, ball->y_position);
				return true;
			}
		}
	}


	return false;
}

/*
 * Checks if a right collision has occurred on a block.
 */
static bool block_right(double oldX, double oldY, struct Ball *ball, struct Block *block)
{
	// first simple rejection
	if (ball->y_velocity < ZERO)
	{
		// second simple rejection
		if (block->x_position <= oldX <= (block->x_position + TWO))
		{
			// intersection test
			if (oldY >= block->y_position + ONE || oldY <= block->y_position)
			{
				right_collision(oldX, ball, block->x_position);
				bounce_message(ball->color, "block right side", ball->x_position, ball->y_position);
				return true;
			}
		}
	}

	return false;

}

/*
 * Enacts a top block collision.
 */ 
static void block_up(double oldX, double oldY, struct Ball *ball, struct Block *block)
{
	if (block->y_position <= oldY <= block->y_position + ONE)
	{
		if (oldX >= block->x_position + ONE || oldX <= block->x_position)
		{
			up_down_collision(oldY, ball, block->y_position);
			bounce_message(ball->color, "block top side", ball->x_position, ball->y_position);
		}
	}
}

/*
 * Enacts a bottom block collision.
 */
static void block_down(double oldX, double oldY, struct Ball *ball, struct Block *block)
{
	up_down_collision(oldY, ball, block->y_position);
	bounce_message(ball->color, "block bottom side", ball->x_position, ball->y_position);
}


/*
 * Checks the position of the ball after basic motion is applied to see if any collisions
 * were made with a wall.
 */
static void wall_collision(struct Ball *ball)
{
	if (ball->x_position < LEFT_WALL)
	{
		ball->x_position = left_collision(ball->x_position, ball, LEFT_WALL);
		bounce_message(ball->color, "left wall", ball->x_position, ball->y_position);
	}
	else if (ball->x_position > RIGHT_WALL)
	{
		ball->x_position = right_collision(ball->x_position, ball, RIGHT_WALL);
		bounce_message(ball->color, "right wall", ball->x_position, ball->y_position);
	}
	else if (ball->y_position > TOP_WALL)
	{
		ball->y_position = up_down_collision(ball->y_position, ball, TOP_WALL);
		bounce_message(ball->color, "top wall", ball->x_position, ball->y_position);
	}
}
	
/*
 * Executes the changes on the ball whenever a paddle collision occurs.
 * Changes include:
 * - Ball takes on the color of the paddle
 * - The usual changes for an up/down collision
 */
static void paddle_collision(struct Ball *ball)
{
	for (int i = ZERO; i < EIGHT; i++)
	{
		struct Paddle *paddle = &ball->game->paddles[i];
		if ((ball->y_position <= BOTTOM_FIELD) && (ball->x_position >= (paddle->x_position - paddle->size)) && (ball->x_position <= (paddle->x_position + paddle->size)) && (ZERO != paddle->color))
		{
			ball->y_position = up_down_collision(ball->y_position, ball, BOTTOM_FIELD);
			ball->color = paddle->color;
			bounce_message(ball->color, "paddle", ball->x_position, ball->y_position);
		}
	}
} 

// check the simple cases to see if a block collision has occurred
static int block_collision_cases(struct Ball *ball, struct Block *block)
{
	// do left/right cases first, then up/down
	double oldX = ball->x_position - DELTA_T * ball->x_velocity;
	double oldY = ball->y_position - DELTA_T * ball->y_velocity;

	if(block_left(oldX, oldY, ball, block))return ONE;
	else if(block_right(oldX, oldY, ball, block))return ONE;
	else
	{
		if(ball->y_velocity < ZERO)block_up(oldX, oldY, ball, block);
		else block_down(oldX, oldY, ball, block);
		return ONE;
	}
}

/*
 * Executes the changes on the ball whenever a block collision occurs.
 */
static bool block_collision(void *data, void *helper)
{
	/* First check if ONE of the four conditions are true:
	 * If ball[x_position] < block[x_position]
	 * If ball[x_position] > block[x_position]
	 * If ball < block[y_position]
	 * If ball > block[y_position]
	 * If one is true, then the ball did not collide and this case can be ignored.
	 */
	struct Block *block = data;
	struct Ball *ball = helper;

	if(((ball->x_position <= (block->x_position + THREE)) && (ball->x_position > block->x_position)) && ((ball->y_position > block->y_position) && ball->y_position <= (block->y_position + TWO)))
	{
		block_collision_cases(ball, block);
		ball->game->paddles[ball->color].score += block->color * TEN;
		return true;
	}

	return false;
}

/*
 * Updates the ball by applying basic motion and then checking for 
 * any collisions with blocks, walls, or paddles.
 */
static void update_ball(struct Ball *ball)
{
	// apply basic motion
	ball->x_position = basic_motion(ball->x_position, ball->x_velocity);
	ball->y_position = basic_motion(ball->y_position, ball->y_velocity);
	
	// check for any block, wall, and then paddle collisions
	deleteSome(&ball->game->obstacle, block_collision, ball, free_thing, TEXT);
	wall_collision(ball);
	paddle_collision(ball);
}

// ActionFunction used by iterate to update all the balls
static void update_balls(void *data)
{
	struct Ball *ball = data;
	update_ball(ball);
}

// CriteriaFunction that checks if the ball is outside the playing field
static bool ball_outside_bounds(void *data, void *helper)
{
	struct Ball *ball = data;
	if((ball->y_position < BOTTOM_FIELD) || (ball->y_position > TOP_WALL) || (ball->x_position < LEFT_WALL) || (ball->x_position > RIGHT_WALL))
	{
		// ball is out of bounds
		ball_leave(ball);
		return true;
	}
	else
	{
		return false;
	}
}

// CriteriaFunction that always returns true
bool always_true(void *data, void *helper)
{
	return true;
}

// clear the ball and blocks list of the sim
// the code for this is heavily based on Neil Kirby's l3_ref.zip sim.c code in the same function
static void clear_lists(struct Sim *simulation)
{
	int remove;
	// clear ball list
	remove = deleteSome(&simulation->bounce, always_true, NULL, free_thing, TEXT);
	if(TEXT)printf("removed %d balls\n", remove);
	// clear block list
	remove = deleteSome(&simulation->obstacle, always_true, NULL, free_thing, TEXT);
	if(TEXT)printf("removed %d blocks\n", remove);
}

// attempt to run the game
static void play_game(bool ballOnField, struct Sim *simulation)
{

	// first sort the ball list
	sort(simulation->bounce, Y_compare);

	// next output the state of the simulation
	master_output(simulation);

	// then update the elapsed time
	(simulation->elapsed) += DELTA_T;

	// then update the balls by iterating through the list
	iterate(simulation->bounce, update_balls);
	deleteSome(&simulation->bounce, ball_outside_bounds, NULL, free_thing, TEXT);
}

/*
 * Function that runs for as long as the sim does. Returns a false value if bad input was given
 * by the user.
 */
bool do_everything(char *file)
{
	struct Sim sim = {D_ZERO, NULL}, *simulation = &sim;

	// collect input
	bool ballOnField = collectInput(simulation, file);

	// if input is good, set ballOnField to true 
	while(NULL != simulation->bounce)
	{
		play_game(ballOnField, simulation);
	}

	final_output(simulation, simulation->bounce, simulation->obstacle, simulation->paddles);

	clear_lists(simulation);

	return ballOnField;
}


