/* I AM GETTING A 0 ON THIS LAB */

bool collectInput(struct Sim *simulation, char *file_name);
