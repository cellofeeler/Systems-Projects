// COpyright 2024 Neil Kirby.  Not for disclosure without permission
// Chloe Feller

#include "subscripts.h"

struct Ball {
	int color;
	double x_position, y_position, x_velocity, y_velocity;
	struct Sim *game;
};

struct Paddle {
	int paddleNum;
	int color, score;
	double x_position, size;
	struct Sim *game;
};

struct Block {
	int color;
	double x_position, y_position;
};

struct Sim {
	double elapsed;
	void *bounce;
	void *obstacle;
	struct Paddle paddles[EIGHT];
};

