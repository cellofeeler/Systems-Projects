// Copyright 2024 Neil Kirby 
// Not for disclosure without permission

// system libraries rarely have bugs, do them first
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// custom libraries and things like custom libraries go here
#include "n2.h"
#include "debug.h"
#include "bko.h"
#include "structs.h"

// do C code headers last, this file.s header dead last.
#include "sim.h"
#include "output.h"
#include "input.h"

// my own header file is included dead last.  IT is MANDATORY!
#include "lab4.h"



/* I own all inits.  In future labs, I might morph to master init and call
 * my init minions to do the various subtasks.  For now, I'm simple enough
 * to do it all easily myself.  I shield main for all details about
 * initializations */
/* Note: this function was originally written by Neil Kirby, however I (Chloe Feller) ended up changing the code. 
 * So everything in this function is written by me EXCEPT the non-false return statement.*/
bool init(int count)
{
	if(TWO == count)
	{
		if(DEBUG)printf("DIAGNOSTIC: Argc is correct! Running sim...\n");
		return (TEXT || (GRAPHICS && bko_initialize()));
	}
	else if(THREE == count)
	{
		if(TEXT)printf("ERROR: Project does not have bonus mode. Returning false...\n");
		return false;
	}
	else
	{
		if(TEXT)printf("ERROR: argc has %d arguments, which doesn't work for this program.\n", count);
		return false;
	}

}

/* Put all of the toys away.  In future labs I will own more stuff and
 * call my minions to do those things. */
void teardown()
{
        if(GRAPHICS)bko_teardown();
}

/* Avoid details and call upon my minions to make it everything happen.  I own
 * those highest level things that I must own: performance timing and the
 * value we return to linux */

#define RVAL_BAD_INIT (1)
#define RVAL_BAD_INPUT (2)

int main(int argc, char *argv[])
{
        int rval = EXIT_SUCCESS;
        double start, runtime;

        start = now();  // this is the very first executable statement

        if( init(argc))
        {
            if( !do_everything(argv[ONE])) rval = RVAL_BAD_INPUT;
            teardown();
        }
        else
        {
            rval = RVAL_BAD_INIT;       // non zero, indicates an error
        }

        /* at this point we are done, graphics has been torn down*/
        printf("Returning %d\n", rval);
        runtime = now() - start;
        /* after graphics has been torn down, we can freely print */
        printf("Total runtime is %.9lf seconds\n", runtime);

        return rval;
}


