/* Chloe Feller */

// system libraries first since they rarely have bugs
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// then custom libraries
#include "structs.h"
#include "libll.h"

// constants next
#include "constants.h"
#include "subscripts.h"
#include "debug.h"

// C code headers last
#include "lab3.h"
#include "sim.h"
#include "memory.h"
#include "output.h"

// this file's header file included dead last
#include "input.h" 

/* inserts a ball's data into the ball linked list
 */
static bool insert_ball(struct Sim *simulation, struct Ball *ptrBall)
{
	bool added;

	struct Ball *allocated = allocate_thing((sizeof(struct Ball)));
	*allocated = *ptrBall;
	
	added = insert(&simulation->bounce, allocated, Y_compare, TEXT);

	return added;
}

/*
 * Read data for ball
 */
static bool read_balls(struct Sim *simulation, FILE *file)
{

	// First collect number of balls...
	// Note: if scanf fails to read correctly, indicate a failure but KEEP GOING
	int ballNum, temp;
	struct Ball ball, *ptrBall = &ball;
	ptrBall->game = simulation;
		
	if (ONE != (temp = fscanf(file, "%d", &ballNum)))
	{
		scanf_message("read_ball", temp, ONE);
	}

	// Then use that number to loop and store ball data...  
	for (int i = ZERO; i < ballNum; i++)
	{
		// scan ball info in
		if(FIVE == (temp = fscanf(file, "%d %lf %lf %lf %lf", &(ball.color), &(ball.x_position), &(ball.y_position), &(ball.x_velocity), &(ball.y_velocity))))
		{
			if(!insert_ball(simulation, ptrBall))
			{
				free_thing(ptrBall);
				return false;
			}
		}
	}

	return true;
}

/*compare the Y and X values of the blocks (X value only compared when Y values are equal), and return true if
 * data_one belongs earlier than data_two
 */
static bool compare_blocks(void *data_one, void *data_two)
{
	bool above;

	if(DEBUG)printf("DEBUG SORT: Assigning void pointers to block structs...\n");
	struct Block *block_one = data_one, *block_two = data_two;

	if((block_one->y_position == block_two->y_position))
	{
		if(DEBUG)printf("DEBUG: Comparing %lf and %lf...\n", block_one->x_position, block_two->x_position);
		return above = ((block_one->x_position) > (block_two->x_position));
	}
	else
	{
		if(DEBUG)printf("DEBUG: Comparing %lf and %lf...\n", block_one->y_position, block_two->y_position);
		return above = ((block_one->y_position) > (block_two->y_position));
	}

	
}

/* Insert block data, return false if not added.
 */
static bool insert_block(struct Sim *simulation, struct Block *block)
{
	bool added;

	struct Block *allocated = allocate_thing(sizeof(struct Block));
	*allocated = *block;

	added = insert(&simulation->obstacle, allocated, compare_blocks, TEXT);

	return added;
}

/*
 * Read ball data.
 */
static bool read_blocks(struct Sim *simulation, FILE *file)
{
	// First collect number of blocks...
	// Note: if scanf fails to read correctly, indicate a failure but KEEP GOING
	int blockNum, temp;
	struct Block block, *ptrBlock = &block;

	if (ONE != (temp = fscanf(file, "%d", &blockNum)))
	{
		scanf_message("read_block", temp, ONE);
	}

	/*
	 * Then use that number to loop and store block data...
	 */
	for (int i = ZERO; i < blockNum; i++)
	{
		// scan block info in
		if (THREE == (temp = fscanf(file, "%d %lf %lf", &(block.color), &(block.x_position), &(block.y_position))))
		{
			if(!insert_block(simulation, ptrBlock))
			{
				printf("Block %d was not inserted.\n", (block.color));
				return false;
			}
		}
	}

	return true;
}

/* Insert paddle data, return false if not inserted.
 */
static bool insert_paddles(struct Sim *simulation, struct Paddle *paddle, const int paddleNum)
{
	paddle->score = ZERO;

	if(ZERO > (paddle->size) || (ZERO >= (paddle->color) > SEVEN))
	{
		printf("Paddle does not meet required size or color requirements.\n");
		return false;
	}
	else
	{
		if(DEBUG)printf("DEBUG: Inserting paddle %d...\n", paddleNum);
		simulation->paddles[paddle->color] = *paddle;
	}

	return true;;

}

/*
 * Read paddle data.
 */
static bool read_paddles(struct Sim *simulation, FILE *file)
{
	// First collect number of paddles...
	// Note: if scanf fails to read correctly, indicate a failure but KEEP GOING
	const int paddleNum;
	int temp;
	struct Paddle paddle, *ptrPaddle = &paddle;

	if (ONE != (temp = fscanf(file, "%d", &(paddle.paddleNum))))
	{
		scanf_message("read_paddle", temp, ONE);
	}

	/*
	 * Then use that number to loop and store paddle data...
	 */
	for (int i = ONE; i < (paddle.paddleNum + ONE); i++)
	{
		if (THREE == (temp = fscanf(file, "%d %lf %lf", &(paddle.color), &(paddle.x_position), &(paddle.size))))
		{
			simulation->paddles->paddleNum = paddle.paddleNum;
			if(!insert_paddles(simulation, ptrPaddle, (i)))
			{
				printf("Paddles not inserted.\n");
				return false;
			}
		}
	}

	return true;
}

// attempts to open the file given by the user
static FILE *file_attempt_open(char *file_name)
{
	FILE *open_file;

	if(NULL == (open_file = fopen(file_name, "r")))
	{
		if(TEXT)printf("ERROR: Unable to open %s for reading.\n", file_name);
		return NULL;
	}
	else
	{
		if(TEXT)printf("DIAGNOSTIC: Successfully opened %s for reading.\n", file_name);
		return open_file;
	}
}

// attempts to close thhe file given by the user
static int file_attempt_close(FILE *open_file)
{
	if(NULL == open_file)
	{
		if(TEXT)printf("DIAGNOSTIC: Input file unable to open, so it is already closed.\n");
		return ONE;
	}
	else
	{
		if(EOF == fclose(open_file))
		{
			if(TEXT)printf("ERROR: failed to close input file.\n");
			return ZERO;
		}
		else
		{
			if(TEXT)printf("DIAGNOSTIC: input file closed.\n");
			return ONE;
		}
	}
}

/*
 * collects input from user
 */
bool collectInput(struct Sim *simulation, char *file_name)
{
	FILE *file;

	// open the file given by the user
	file = file_attempt_open(file_name);
	
	// collect ball, block, then paddle data
	if(NULL != file)
	{
		if(!read_balls(simulation, file) || !read_blocks(simulation, file) || !read_paddles(simulation, file))
		{
			if(TEXT)printf("ERROR: Input file not formatted correctly, cannot run sim.");
			return false;
		}
	}

	if(ZERO == file_attempt_close(file))
	{
		return false;
	}

	return true;
}

