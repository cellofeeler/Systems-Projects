/* I AM GETTING A 0 ON THIS LAB */

void *allocate_thing(size_t n);
void free_thing(void *thing);
