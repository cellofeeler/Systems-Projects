/* I AM GETTING A 0 ON THIS LAB */

bool init();
int main();
void teardown();
