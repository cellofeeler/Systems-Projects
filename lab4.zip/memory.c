/* Chloe Feller */
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

#include "altmem.h"
#include "debug.h"
#include "structs.h"
#include "constants.h"
#include "output.h"

#include "memory.h"

// Allocate memory for either the ball or block struct.
// Note n is used to differentiate between the differing amount of memory to allocate in the two structs
void *allocate_thing(size_t n)
{
	static int objects = ZERO;

	// allocate memory
	void *allocate = alternative_malloc(n);

	if (NULL == allocate)
	{
		if(TEXT)
		{
			printf("DIAGNOSTIC: allocate_thing: NO bytes allocated for object %d\n", objects++);
		}
	}
	else
	{
		if(TEXT)printf("DIAGNOSTIC: allocate_thing: %ld bytes allocated for object %d\n", n, objects++);
		if(DEBUG)printf("DEBUG: allocate_thing: returning %p\n", allocate);
	}

	return allocate;
}

// Free memory, giving diagnostics and debugs
// The code used in this function is from Neil Kirby's l3_ref.zip "memory.c" file
void free_thing(void *thing)
{
	static int objects = ZERO;
	if(NULL != thing)
	{
		if(DEBUG)
		{
			printf("DEBUG: free_thing: freeing %p\n", thing);
			fflush(stdout);
		}
		alternative_free(thing);
		objects++;
		if(TEXT)printf("DIAGNOSTIC: free_thing: %d objects freed\n", objects);
	}
	else
	{
		if(TEXT)printf("ERROR: free_thing: attempt to deallocate NULL\n");
	}

}

